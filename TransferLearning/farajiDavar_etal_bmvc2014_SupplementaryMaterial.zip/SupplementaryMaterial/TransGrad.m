function [X_src,Acc,data,Avg_Acc,prob,posterior,Cls]=TransGrad(X_src,X_tar,Y_src,Y_tar,Acc,Avg_Acc,info)
[n_src_samples,dimension] = size(X_src);

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% GMM Initialization with random KNN
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for tt=1:info.TransGrad_iter
        Data= X_tar';
        disp('GMM Clustering');
        numClusters = min(info.clusters,floor(n_src_samples/5));
        % Run KMeans to pre-cluster the data
        [initMeans, assignments] = vl_kmeans(Data, numClusters, ...
            'Algorithm','Lloyd', ...
            'MaxNumIterations',10);
       
        
        initCovariances = zeros(dimension,numClusters);
        initPriors = zeros(1,numClusters);
        
        % Find the initial means, covariances and priors
        for i=1:numClusters
            data_k = Data(:,assignments==i);
            initPriors(i) = size(data_k,2) / numClusters;
            
            if size(data_k,1) == 0 || size(data_k,2) == 0
                initCovariances(:,i) = diag(cov(Data'));
            else
                initCovariances(:,i) = diag(cov(data_k'));
            end
        end

       
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% GMM fitting
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        [means, covariances, priors,ll, posteriors] = vl_gmm(Data, numClusters, ...
            'initialization','custom', ...
            'InitMeans',initMeans, ...
            'InitCovariances',initCovariances, ...
            'InitPriors',initPriors);
        
        GMM.means=means;
        GMM.covariances=covariances;
        GMM.priors=priors;
        GMM.ll =ll;
        GMM.posteriors=posteriors;
%         save(fullfile(info.resultsDir,'GmmModel.mat'),'-struct','GMM','-v7.3');
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% Gradient computation
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        disp('Gradient Encoding');
%         load(fullfile(info.resultsDir,'GmmModel.mat'));
%         load(fullfile(info.resultsDir,'PCA_vector.mat'));
   
        for i=1:n_src_samples
            enc=vl_fisher(X_src(i,:)',means,covariances,priors,'Improved');
            Fisher{i}=enc;
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% src data likelihood estimation using the trg GMM
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        p=zeros(n_src_samples,numClusters);
        for i=1:numClusters
            for j=1:n_src_samples
                tmpDist = X_src(j,:) - means(:,i)';
                p(j,i) = exp((-1/2)*tmpDist*diag(1./covariances(:,i))*tmpDist')/sqrt(prod(covariances(:,i))*((2*pi)^(dimension)));
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% Computing src translations
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        p_j=zeros(n_src_samples,1);
        for i=1:n_src_samples
            tmp=Fisher{1,i};
            uk{i}=mean(reshape(tmp(1:length(tmp)/2),numClusters,dimension));
            p_j(i)=sum(priors'.*p(i,:));
        end
        
        translated_X_src = zeros(size(X_src));
        for i=1:n_src_samples
            translated_X_src(i,:) = X_src(i,:) + info.step*uk{i};
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% Classification accuracy after src translations
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        fprintf('FK_based Global adaptation.... \n');
        [Mean_Cls_acc,acc,prob,posterior,Cls]=Classify(translated_X_src,X_tar,Y_src,Y_tar,info);
        Acc = [Acc;acc];
        Avg_Acc = [Avg_Acc;Mean_Cls_acc];
        X_src = translated_X_src;
        data=[X_src;X_tar];
    end
