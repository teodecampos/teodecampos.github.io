function [Z,A] = SSD(Xs,Xt,Ys,Yt0,options,info)
if nargin < 5
    error('Algorithm parameters should be set!');
end
if ~isfield(options,'k')
    options.k = 100;
end
if ~isfield(options,'lambda')
    options.lambda = 0.1;
end
if ~isfield(options,'ker')
    options.ker = 'primal';
end
if ~isfield(options,'data')
    options.data = 'default';
end
if strcmp(info.database,'ICCV')
        data = [Xs;Xt];
        [pc,score,latent] = princomp(data);
        sqrtErr = cumsum(latent)./sum(latent);
        A = pc(:,1:options.k);
        Z = data*A;
else
%% Transfer Feature Learning with Joint Distribution Adaptation. ICCV 2013 Manuscript.

%% Load algorithm options

k = options.k;
lambda = options.lambda;
ker = options.ker;
data = options.data;

fprintf('JDA:  data=%s  k=%d  lambda=%f\n',data,k,lambda);

%% Set predefined variables
X = [Xs,Xt];
X = X*diag(sparse(1./sqrt(sum(X.^2))));
[m,n] = size(X);
ns = size(Xs,2);
nt = size(Xt,2);

%% Construct MMD matrices
e = [1/ns*ones(ns,1);-1/nt*ones(nt,1)];
M = e*e'*length(unique(Ys));
M = M/norm(M,'fro');

%% Construct centering matrix
H = eye(n)-1/(n)*ones(n,n);

%% Joint Distribution Adaptation: JDA using PCA
if strcmp(ker,'primal')
    [A,~] = eigs(X*M*X'+lambda*eye(m),X*H*X',k,'SM');
    Z = A'*X;
else
    K = kernel(ker,X,sqrt(sum(sum(X.^2).^0.5)/n));
    [A,~] = eigs(K*M*K+lambda*eye(n),K*H*K,k,'SM');
    Z = A'*K;
end
end
fprintf('Algorithm SSD terminated!!!\n\n');

end
