function [Mean_Cls_acc,acc,prob,posterior,Cls]=Classify(X_src,X_tar,Y_src,Y_tar,info)
if strcmp(info.classifier,'LR')
    addpath(genpath('/user/cvssppgr/nf00045/MatlabLocal/ICCV2013/360Sup/liblinear/matlab'));
    model = train(Y_src,sparse(X_src),'-s 0 -c 1 -q 1');
    [Cls,acc,prob] = predict(Y_tar,sparse(X_tar),model);
    acc=acc(1);
    [Mean_Cls_acc,~,~,posterior]=PREDICT(Cls,X_tar,Y_tar);
elseif strcmp(info.classifier,'KDA')
    
    [projTrain, projTest, posterior,acc,Mean_Cls_acc,Cls] = KDA(X_src,X_tar,Y_src,Y_tar,'2',info);
    if info.KDA_Pflag ==1
        [~,~,prob,~]=PREDICT(Cls,X_tar,Y_tar);
    else
        [~,~,prob,posterior]=PREDICT(Cls,X_tar,Y_tar);
    end
    fprintf('KDA=%0.4f\n',acc);
elseif strcmp(info.classifier,'SVM')
    addpath('/user/cvssppgr/nf00045/Matlab/CodesAndData_others/libsvm-3.17/matlab')
    if ~exist(strcat(src_dataset,'_svm_parameters.mat'),'file')
        [C G]=CrossValParamSelect(X_src,Y_src,5);
        svm_parameters = [C,' ',G];
        save(strcat(info.src_dataset,'_svm_parameters.mat'),'svm_parameters')
    else
        load(strcat(info.src_dataset,'_svm_parameters.mat'));
        [C,G]=strtok(svm_parameters);
    end
    str = sprintf('%s %s %s %s','-c ',C,'-g',G);
    model = svmtrain(Y_src, X_src, str);
    [Cls, acc, dec_values] = svmpredict(Y_tar, X_tar, model);
    acc=acc(1);
    
    fprintf('SVM=%0.4f\n',acc(1));
    [Mean_Cls_acc,~,prob,posterior]=PREDICT(Cls,X_tar,Y_tar);
    
elseif strcmp(info.classifier,'NN')
    Cls = knnclassify(X_tar,X_src,Y_src,1);
    acc = length(find(Cls==Y_tar))/length(Y_tar); fprintf('NN=%0.4f\n',100*acc);
    [Mean_Cls_acc,~,prob,posterior]=PREDICT(Cls,X_tar,Y_tar);
    
end

