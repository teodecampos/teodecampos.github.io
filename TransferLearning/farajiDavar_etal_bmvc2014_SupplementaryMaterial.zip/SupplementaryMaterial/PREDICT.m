function [Mean_Cls_acc,overall_acc,prob,posterior]=PREDICT(Cls,X_tar,Y_tar)
nClasses = size(unique(Y_tar),1);
accuracy = zeros(nClasses,1);
C=unique(Y_tar);
for c=1:nClasses
    accuracy(c) = mean(Cls(Y_tar==C(c))==C(c));
end
Mean_Cls_acc =  100*mean(accuracy);

overall_acc = mean(Cls==Y_tar);
prob = accuracy;

posterior = zeros(size(X_tar,1),nClasses);
for n=1:size(X_tar,1)
    posterior(n,Cls(n)) = 1;
end

