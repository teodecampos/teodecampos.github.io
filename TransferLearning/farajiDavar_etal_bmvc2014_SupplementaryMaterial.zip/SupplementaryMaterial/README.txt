ADAPTIVE TRANSDUCTIVE TRANSFER MACHINES
by Nazli FarajiDavar, Teofilo deCampos and Josef Kittler
{n.farajidavar, t.decampos, j.kittler}@surrey.ac.uk

Supplementary material for the paper above, published at BMVC 2014.

The copyright belongs to the authors above. 
Please contact the authors to make use of this source code
and cite the above paper in any publication that uses it.

ABOUT
   This package demonstrates the pipeline presented in our paper on
   the task of transductive transfer learning between two pairs of
   datasets:
   MNIST and USPS
   Amazon and Caltech
   This package shall enable the reader to reproduce some of the 
   results presented in the last column of table 3 of the paper.

REQUIREMENTS
   The code prented here requires a recent version of Matlab
   and the vl_feat library, version 0.9.17, which should be 
   downloaded and installed in this subdirectory of the local directory:
   vlfeat-0.9.17
   Alternatively, vl_feat can be added to Matlab path, in which case, 
   please edit main.m appropriately.
   vl_feat can be obtained from http://www.vlfeat.org/download.html
   More specifically, from 
   http://www.vlfeat.org/download/vlfeat-0.9.17.tar.gz
   Please follow the instructions in the README file of the 
   vlfeat-0.9.17 directory. In Linux, run this:
   $ cd vlfeat-0.9.17
   $ make
   In many linux machines, the mex executable from LaTeX is ahead
   of MatLab in the path. In that case, you might need to run.
   $ make MEX=<path to MatLab mex executable>

RUNNING THE EXPERIMENTS
   In Matlab console:
   >> main
   The script main.m is the main program, which loads the 
   data sets, models them and compute the transformations 
   following each step described in the paper. 
   It then classifies the unlabeled target data.

   Parameters:
     info.classifier: type of the classifier which is of interest
     info.database: feature space indicator where'Caltech+office' corresponds to the SURF features of 
                    the Caltech+office datasets and 'ICCV' corresponds to the raw features of the 
                    MNIST and USPS datasets
     info.src_dataset: name of the source dataset from set ('MNIST','USPS','amazon','caltech') 
     info.tar_dataset: name of the source dataset from set ('MNIST','USPS','amazon','caltech') 
     info.clusters: number of the GMM componants of the TrasGrad method, initialized with 20
     info.step: the translation rate of the TrasGrad method, initialized with 5
     info.TransGrad_iter: number of iterations for the TrasGrad method which initially has set to 1(no iterations);
     info.theta: the transfer rate for the class-specific transformation of the TST step, initialized to 0.5
