function [G_transform,indices]=Trans_Unit(Xs,Xt,trainlabels,posterior,result_path,pivot_features)

%serching and removing the non-pivot features of the target domain
Mask = zeros(1,size(Xs,2));
if pivot_features
    indices = find(std(Xt) >= 20 & std(Xs) >= 20);
    Xs= Xs(:,indices);
    Xt = Xt(:,indices);
else
    indices = 1:1:size(Xt,2);
end
Mask(indices)=1;   

trainlabels=trainlabels+1;

    [E_target,E_source,sigma_target,sigma_source]=applyTransfer(Xs, trainlabels, posterior, Xt);
    G_transform=zeros(size(Xs));
    
    for i=1:size(Xs,1);
        c=trainlabels(i);
        G_transform(i,:)=E_target(c,:)  + ((Xs(i,:)-E_source(c,:)).*sigma_target(c,:))./sigma_source(c,:);
    end
    S = sigma_target./sigma_source;
    DX= E_source./S + E_target;
    n_classes= numel(unique(trainlabels));
    s=zeros(size(Xs,2),size(Xs,2),n_classes);
    Beta = zeros(size(Xs,2),size(Xs,2)+1,n_classes);
    for c=1:n_classes;
        s(:,:,c)=diag(S(c,:));
        Beta(:,:,c) = [s(:,:,c),DX(c,:)'];
    end
    save(fullfile(result_path,'Beta.mat'), 'Beta'); 
    save(fullfile(result_path,'E_source.mat'), 'E_source');
    save(fullfile(result_path,'E_target.mat'), 'E_target');
    save(fullfile(result_path,'sigma_source.mat'), 'sigma_source');
    save(fullfile(result_path,'sigma_target.mat'), 'sigma_target');




end