function [E_target,E_source,sigma_target,sigma_source]=applyTransfer(Xs, trainlabels, posterior, Xt)
  nClasses = size(posterior, 2);
  dim = size(Xs,2);
  E_source = zeros(nClasses, size(Xs,2));
  E_target = zeros(nClasses, size(Xs,2));

  for c=1:nClasses
    E_source(c,:) = mean(Xs(trainlabels==c,:));
    sigma_source(c,:) = std(Xs(trainlabels==c,:));
  end
  
  

  for c=1:nClasses
    if sum(posterior(:,c)) == 0
        E_target(c,:)= zeros(1,dim);
        sigma_target(c,:)=  ones(1,dim);
    else
        posteriorRep = repmat(posterior(:,c), [1, size(Xt,2)]);
        Xt_posterior = Xt .* posteriorRep;
        E_target(c,:) = sum(Xt_posterior)/sum(posterior(:,c));
        E_targetRep = repmat(E_target(c,:), [size(Xt,1) 1]);
        sigma_target(c,:) = sqrt(sum(posteriorRep.*(Xt-E_targetRep).^2)/sum(posterior(:,c)));
    end
   end

for c=1:nClasses
      for j=1: size(Xs,2)
          if sigma_source(c,j)==0 && sigma_target(c,j)~=0
              sigma_source(c,j)=sigma_target(c,j);
          elseif  sigma_source(c,j)==0 && sigma_target(c,j)==0
              sigma_source(c,j)=1;
          end
      end
end


