
clear all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% vl_feat package
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
workingDir = pwd;
cd ./vlfeat-0.9.17/toolbox;
vl_setup
vl_version verbose
cd(workingDir)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Parameters initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[x x x]=mkdir(workingDir,'expResults');
info.resultsDir = fullfile(workingDir,'expResults');
info.classifier='NN';
info.database='ICCV';%'Caltech+office';%
info.src_dataset ='MNIST'; % 'amazon'; % 
info.tar_dataset ='USPS'; %'caltech'; % 
info.clusters = 20;
info.TransGrad_iter=1;
info.path = pwd;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Loading src/trg data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[X_src,Y_src]=LOAD_DATA(info.src_dataset,10,info.classifier);
[X_tar,Y_tar]=LOAD_DATA(info.tar_dataset,10,info.classifier);
X_src=X_src';
X_tar=X_tar';
[Clust_dsim,Glob_dsim]=DA_Similaity(info.src_dataset,info.tar_dataset);
if Clust_dsim < 0.03
    info.KDA_sigma = 1;
else
    info.KDA_sigma = 10;
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Computing baseline classification results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Baseline classification accuracy... \n')
nClasses = size(unique(Y_tar),1);
Acc = [];
Avg_Acc =[];
result = [];
[Mean_Cls_acc,acc,prob,posterior,Cls]=Classify(X_src,X_tar,Y_src,Y_tar,info);
Acc = [Acc;acc];
Avg_Acc = [Avg_Acc;Mean_Cls_acc];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PCA/MMD dimentionality reduction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
if (strcmp(info.database,'ICCV') && strcmp(info.classifier,'NN'))
    data = [X_src;X_tar];
    options.k =40;
    info.step = 5;
    [Z,A] = SSD(X_src,X_tar,Y_src,Cls,options,info);
    data = Z;
        
elseif strcmp(info.database,'Caltech+office')
    Cls=[];
    options.k = 100;
    info.step = -1;
    options.ker = 'linear';
    options.lambda = 1.0;
    options.gamma = 1.0;        % kernel bandwidth: rbf only
    [Z,A] = SSD(X_src',X_tar',Y_src,Cls,options,info);
    Z = Z*diag(sparse(1./sqrt(sum(Z.^2))));
    data=Z';
    low_proj = A;
end
indice = size(X_src,1);
X_src=data(1:indice,:);
X_tar=data(indice+1:end,:);
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Classification accuracy after dimensionality reduction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Classification accuracy after dimensionality reduction... \n')
nClasses = size(unique(Y_tar),1);
Acc = [];
Avg_Acc =[];
result = [];
[Mean_Cls_acc,acc,prob,posterior,Cls]=Classify(X_src,X_tar,Y_src,Y_tar,info);
Acc = [Acc;acc];
Avg_Acc = [Avg_Acc;Mean_Cls_acc];
[n_src_samples,dimension] = size(X_src);
Time{1}=toc;

if (Glob_dsim > 0.5) && (Clust_dsim > 0.03)
    [X_src,Acc,data,Avg_Acc,prob,posterior,Cls]=TransGrad(X_src,X_tar,Y_src,Y_tar,Acc,Avg_Acc,info);
end
Time{2}=toc;

%%%%%%%%%%%%%%%%%%%%%%%
%% Class-specific translations / tran+scaling approach
%%%%%%%%%%%%%%%%%%%%%%%

T=min(10,floor(10*Glob_dsim));
info.theta=0.5;
G = X_src;
for t = 1:T
    info.in_loop=1;
    fprintf('==============================Iteration [%d]==============================\n',t);
    idx = ones(size(Y_src));
    [G_transform,indices]=Trans_Unit(G,X_tar,Y_src-1,posterior,info.resultsDir,0); %computing the source transformation matrix
    G=info.theta*X_src+(1-info.theta)*G_transform;
    [Mean_Cls_acc,acc,prob,posterior,Cls]=Classify(G,X_tar,Y_src,Y_tar,info);
    Acc = [Acc;acc];
    Avg_Acc = [Avg_Acc;Mean_Cls_acc];
    
end
Time{3}=toc;
result = [result;Acc(end)];

