TRANSDUCTIVE TRANSFER MACHINE

AUTHORS
   Nazli FarajiDavar <n.farajidavar@surrey.ac.uk>
   Teofilo deCampos
   Josef Kittler

   CVSSP, University of Surrey
   Guildford, GU2 7XH
   United Kingdom


DISCLAIMER

   Copyright (C) 2014, Nazli FarajiDavar, Teofilo deCampos and Josef Kittler. 
   All rights reserved. Redistribution and use, with or without
   modification, are permitted provided that the following conditions
   are met:

   * The software is provided under the terms of this license strictly
     for academic, non-commercial, not-for-profit purposes.
   * For any commercial use, please contact the authors in advance.
   * Redistributions of source code must retain the above copyright
     notice, this list of conditions (license) and the following
     disclaimer.
   * The name of the authors may not be used to endorse or promote
     products derived from this software without specific prior
     written permission.
   * As this software depends on other libraries, the user must adhere
     to and keep in place any licensing terms of those libraries.

   * Any publications arising from the use of this software, including
     but not limited to academic journal and conference publications,
     technical reports and manuals, must cite the following work:
     `N. FarajiDavar, T. deCampos and Josef Kittler. 
      Transductive Transfer Machine. ACCV 2014.'

   THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
   IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
   ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
   OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
   SUCH DAMAGE.


ABOUT
   This package demonstrates the pipeline presented in our paper on
   the task of transductive transfer learning between two pairs of
   datasets:
   MNIST and USPS
   Amazon and Caltech
   This package shall enable the reader to reproduce some of the 
   results presented in the last column of table 3 of the paper.

REQUIREMENTS
   The code prented here requires a recent version of Matlab
   and the vl_feat library, version 0.9.17, which should be 
   downloaded and installed in this subdirectory of the local directory:
   vlfeat-0.9.17
   Alternatively, vl_feat can be added to Matlab path, in which case, 
   please edit main.m appropriately.
   vl_feat can be obtained from http://www.vlfeat.org/download.html
   More specifically, from 
   http://www.vlfeat.org/download/vlfeat-0.9.17.tar.gz
   Please follow the instructions in the README file of the 
   vlfeat-0.9.17 directory. In Linux, run this:
   $ cd vlfeat-0.9.17
   $ make
   In many linux machines, the mex executable from LaTeX is ahead
   of MatLab in the path. In that case, you might need to run.
   $ make MEX=<path to MatLab mex executable>

RUNNING THE EXPERIMENTS
   In Matlab console:
   >> main
   The script main.m is the main program, which loads the 
   data sets, models them and compute the transformations 
   following each step described in the paper. 
   It then classifies the unlabeled target data.

   Parameters:
     info.classifier: type of the classifier which is of interest
     info.database: feature space indicator where'Caltech+office' corresponds to the SURF features of 
                    the Caltech+office datasets and 'ICCV' corresponds to the raw features of the 
                    MNIST and USPS datasets
     info.src_dataset: name of the source dataset from set ('MNIST','USPS','amazon','caltech') 
     info.tar_dataset: name of the source dataset from set ('MNIST','USPS','amazon','caltech') 
     info.clusters: number of the GMM componants of the TrasGrad method, initialized with 20
     info.step: the translation rate of the TrasGrad method, initialized with 5
     info.TransGrad_iter: number of iterations for the TrasGrad method which initially has set to 1(no iterations);
     info.theta: the transfer rate for the class-specific transformation of the TST step, initialized to 0.5
