function [X,Y]=LOAD_DATA(data,supervised,classifier)
switch data
    case 'MNIST'
        load(strcat('./Data/','MNIST_vs_USPS'));
        if supervised==0
           fts = X_src' ./ repmat(sum(X_src',2),1,size(X_src',2)); 
           X_src =zscore(fts,1)';
        else
            X_src = X_src*diag(sparse(1./sqrt(sum(X_src.^2))));
        end
        X=X_src;
        Y=Y_src;
    case 'USPS'
        load(strcat('./Data/','USPS_vs_MNIST'));
        if supervised==0
           fts = X_src' ./ repmat(sum(X_src',2),1,size(X_src',2)); 
           X_src =zscore(fts,1)';
        else
            X_src = X_src*diag(sparse(1./sqrt(sum(X_src.^2))));
        end
       
        X=X_src;
        Y=Y_src;

    case 'amazon'
        load('./Data/amazon_SURF_L10.mat');
        fts = fts ./ repmat(sum(fts,2),1,size(fts,2));
        fts =zscore(fts,1);
        X = fts';
        Y = labels;
    case 'caltech'
        load('./Data/Caltech10_SURF_L10.mat');
        fts = fts ./ repmat(sum(fts,2),1,size(fts,2)); 
        fts =zscore(fts,1);
        X = fts';
        Y = labels;
end
