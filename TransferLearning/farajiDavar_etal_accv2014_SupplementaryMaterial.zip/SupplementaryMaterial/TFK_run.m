% addpath(genpath('../liblinear/matlab'));
addpath('/user/cvssppgr/nf00045/Matlab/Classification/KLDA/KLDA_tennis_SinglevsDouble')
addpath('/user/cvssppgr/nf00045/Matlab/Classification/KLDA');
addpath('/user/cvssppgr/nf00045/Matlab/Classification/KLDA/DrTeo');
clear all;
% numCluster_effect=[];
% for tekrar=1:1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% vl_feat running
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
workingDir = pwd;
% cd /vol/vssp/CDL/Nazli/Code/vlfeat-0.9.17/toolbox;
% vl_setup
% vl_version verbose
% cd(workingDir)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Parameters initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
info.resultsDir = '/user/cvssppgr/nf00045/Latex/TFK/expResults';
info.classifier='NN';
info.database='Caltech+office';%'ICCV';% (Use the 'Caltech+Office' setting for COIL datasets)
info.src_dataset ='amazon';%'TWDA09';
info.tar_dataset ='caltech';%'TWSA03';%'BMSB08'
info.clusters = 20;%tekrar
info.TransGrad_iter=1;
if strcmp(info.database,'ICCV')
    info.step = 5;
else
    info.step = -1;
end
info.path = pwd;
if strcmp(info.classifier,'KDA') && strcmp(info.database,'ACASVA')
    info.KDA_Pflag=1;
else
    info.KDA_Pflag=0;
end
info.in_loop=0;
final_acc=[];
for acc_var_iter=1:1
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Loading src/trg data
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [X_src,Y_src]=LOAD_DATA(info.src_dataset,10,info.classifier);
    [X_tar,Y_tar]=LOAD_DATA(info.tar_dataset,10,info.classifier);
    X_src=X_src';
    X_tar=X_tar';
%     X_src=X_src(Y_src==1|Y_src==2,:);
%     X_tar=X_tar(Y_tar==1|Y_tar==2,:);
%     Y_src=Y_src(Y_src==1|Y_src==2);
%     Y_tar=Y_tar(Y_tar==1|Y_tar==2);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    [pc,score,latent] = princomp(X_tar);
    sqrtErr = cumsum(latent)./sum(latent);
    %     options.k = sum(sqrtErr <= 0.894);
    options.k =100;%% the 37 componants is the same as 90% of energy
    low_proj = pc(:,1:options.k);
    data1 = X_src*low_proj;
    data2= X_tar*low_proj;
    Label='Original Data';
    Diagrams(data1(:,1:3),data2(:,1:3),Y_src,Y_tar,2,Label)
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
%     Label='Original Data';
%     Diagrams(X_src(:,1:3),X_tar(:,1:3),Y_src,Y_tar,2,Label)
    [Clust_dsim,Glob_dsim]=DA_Similaity(info.src_dataset,info.tar_dataset);
    if Clust_dsim < 0.03
        info.KDA_sigma = 1;
    else
        info.KDA_sigma = 10;
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Baseline classification accuracy
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fprintf('Baseline classification accuracy... \n')
    nClasses = size(unique(Y_tar),1);
    Acc = [];
    Avg_Acc =[];
    result = [];
    [Mean_Cls_acc,acc,prob,posterior,Cls]=Classify(X_src,X_tar,Y_src,Y_tar,info);
    Acc = [Acc;acc];
    Avg_Acc = [Avg_Acc;Mean_Cls_acc];
    %     accuracy=nFoldCrossVal_classifier(X_src,Y_src,5,info);
    %     fprintf('Baseline nFold cross validation accuracy %2.2f \n',accuracy)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% PCA/JDA dimentionality reduction
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    tic;
    if (strcmp(info.database,'ICCV') && strcmp(info.classifier,'NN'))
        data = [X_src;X_tar];
        
        [pc,score,latent] = princomp(data);
        sqrtErr = cumsum(latent)./sum(latent);
        %     options.k = sum(sqrtErr <= 0.894);
        options.k =40;%% the 37 componants is the same as 90% of energy
        low_proj = pc(:,1:options.k);
        data = data*low_proj;
        
    elseif strcmp(info.database,'Caltech+office')
        Cls=[];
        options.k = 100;
        options.ker = 'linear';
        options.lambda = 1.0;
        options.gamma = 1.0;        % kernel bandwidth: rbf only
        [Z,A] = JDA(X_src',X_tar',Y_src,Cls,options);
        Z = Z*diag(sparse(1./sqrt(sum(Z.^2))));
        data=Z';
        low_proj = A;
    end
    indice = size(X_src,1);
    X_src=data(1:indice,:);
    X_tar=data(indice+1:end,:);
    Label='MMD effect on 3D space';
    Diagrams(X_src(:,1:3),X_tar(:,1:3),Y_src,Y_tar,2,Label)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Classification accuracy after dimensionality reduction
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fprintf('Classification accuracy after dimensionality reduction... \n')
    nClasses = size(unique(Y_tar),1);
    Acc = [];
    Avg_Acc =[];
    result = [];
    [Mean_Cls_acc,acc,prob,posterior,Cls]=Classify(X_src,X_tar,Y_src,Y_tar,info);
    Acc = [Acc;acc];
    Avg_Acc = [Avg_Acc;Mean_Cls_acc];
    [n_src_samples,dimension] = size(X_src);
    Time{1}=toc;
    %     accuracy=nFoldCrossVal_classifier(X_src,Y_src,5,info);
    %     fprintf('After MMD nFold cross validation accuracy %2.2f \n',accuracy)
    if (Glob_dsim > 0.5) && (Clust_dsim > 0.03)
        [X_src,Acc,data,Avg_Acc,prob,posterior,Cls]=TransGrad(X_src,X_tar,Y_src,Y_tar,Acc,Avg_Acc,info);
        Label='TranGrad effect on 3D data';
        Diagrams(X_src(:,1:3),X_tar(:,1:3),Y_src,Y_tar,2,Label)
%         
        %         accuracy=nFoldCrossVal_classifier(X_src,Y_src,5,info);
        %         fprintf('After TRansGrad nFold cross validation accuracy  %2.2f \n',accuracy)
    end
     Time{2}=toc;
    %%%%%%%%%%%%%%%%%%%%%%%
    %% Class-specific translations / tran+scaling approach
    %%%%%%%%%%%%%%%%%%%%%%%
    if strcmp(info.classifier,'KDA')
        T = floor(10*Glob_dsim);
    else
        T=min(10,floor(10*Glob_dsim));%10
    end
    theta=0.5;
    G = X_src;
    stopping_criteria=10000;
    result_path = '/user/cvssppgr/nf00045/tmp3';
    for t = 1:T
        info.in_loop=1;
        fprintf('==============================Iteration [%d]==============================\n',t);
        idx = ones(size(Y_src));
        [G_transform,indices]=Trans_Unit(G,X_tar,Y_src-1,posterior,'Teo',0,result_path,0,idx); %computing the source transformation matrix
        G=theta*X_src+(1-theta)*G_transform;
        [Mean_Cls_acc,acc,prob,posterior,Cls]=Classify(G,X_tar,Y_src,Y_tar,info);
        Acc = [Acc;acc];
        Avg_Acc = [Avg_Acc;Mean_Cls_acc];
        
        %     D = Dist(G,X_tar);
        %     X_src = G;
    end
     Time{3}=toc;
    Label='TST effect on 3D data';
    Diagrams(G(:,1:3),X_tar(:,1:3),Y_src,Y_tar,2,Label)
    result = [result;Acc(end)];
    fprintf('\n\n\n');
    final_acc=[final_acc;100*Acc(end)];
end
fprintf('std = %2.2f,mean = %2.2f,\n',std(final_acc),  mean(final_acc));
% accuracy=nFoldCrossVal_classifier(X_src,Y_src,5,info);
% fprintf('After TST nFold cross validation accuracy %2.2f \n',accuracy)
% numCluster_effect=[numCluster_effect;mean(final_acc)];
% end


%Time1=[0.3954,0.4009,0.4207,0.3951,0.4123]...0.40+0.01
%Time2=[2.0333,1.9605,2.0999,1.9885,2.0617]...2.03+0.06
%Time3=[4.2629,4.4435,4.4885,4.3491,4.5616]...4.42+0.12