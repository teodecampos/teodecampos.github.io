function [Clust_dsim,Glob_dsim]=DA_Similaity(Data1,Data2)
    src = char(Data1);
    trg = char(Data2);
    [X_src,Y_src]=LOAD_DATA(src,0,'NN');
    [X_tar,Y_tar]=LOAD_DATA(trg,0,'NN');
    
    nClasses =length(unique(Y_src));
    n_features = size(X_src,1);
    nfolds= size(X_src,2)/100;
    ncount=1;
    % for nf=1:nfolds
    %PCA projection
    data= [X_src';X_tar'];
    pc = princomp(data);
    dimension =37;
    data = data*pc(:,1:dimension);
    sdata = data(1:size(X_src,2),:);
    slabel = zeros(size(sdata,1),1);
    tdata = data(size(X_src,2)+1:end,:);
    
    %computing the cluster's centroids in source domain
    src_Mean_mat = zeros(nClasses,37,100);
    Accurate_src_mean = zeros(nClasses,37);
    for rep=1:100
        for c=1:nClasses
            tmp_X_src = sdata(Y_src==c,:);
            tmp_id = randperm(floor(4*size(tmp_X_src,1)/5));
            src_Mean_mat(c,:,rep) = mean(tmp_X_src(tmp_id,:),1);
            Accurate_src_mean(c,:) = mean(tmp_X_src,1);
        end
    end
    %ordering the target data for better clustering results' evaluation
    data=[];
    label=[];
    for c=1:nClasses
        tmp_id = find(Y_tar==c);
        data=[data;tdata(tmp_id,:)];
        label = [label;Y_tar(tmp_id)];
    end
    tlabel = ones(size(label));
    
    %Kmeans clustering
    [IDX,C,sumd,D] = kmeans(data,nClasses,...
        'distance','sqEuclidean',...
        'start',src_Mean_mat,...
        'Replicates',rep,...
        'EmptyAction','singleton');
    S.Sigma = zeros(1,dimension,nClasses);
    S.PComponants = zeros(1,nClasses);
    S.mu = C;
    % Find the initial means, covariances and priors
    for i=1:nClasses
        data_k = data(IDX==i,:);
        S.p(i) = size(data_k,2) / nClasses;
        
        if size(data_k,1) == 0 || size(data_k,2) == 0
            S.Sigma(:,i) = diag(cov(data));
        else
            S.Sigma(1,:,i) = diag(cov(data_k));
        end
    end
    % GMM clustering
    obj = gmdistribution.fit(data,nClasses,'Regularize',1e-4,'Start',S,'CovType','diagonal');
    [idx,nlogl,P] = cluster(obj,data);
   
    D_clusters1=zeros(nClasses);
    for n=1:nClasses
        for m=1:nClasses
            D_clusters1(n,m)= pdist2(Accurate_src_mean(n,:),C(m,:),'euclidean');
        end
    end
    [D1,id]=min(D_clusters1);
    [Mean_Cls_acc,acc,prob,posterior]=PREDICT(IDX,data,label);
    normalizer = max([sdata;tdata])-min([sdata;tdata]);
    normalizer = repmat(normalizer ,[nClasses,1]);
    D=[];
    
    src_centers = Accurate_src_mean./normalizer;
    tar_cluster_centers = C./normalizer;
    Dist=zeros(nClasses,nClasses);
    for c1=1:nClasses
        for c2 =1:nClasses
           Dist(c1,c2) =  pdist([src_centers(c1,:);tar_cluster_centers(c2,:)],'euclidean');
        end
    end
    Clust_dsim=mean(diag(Dist))./nClasses;
    
    
    %NNclustring between the source and target
    src_train_data=[];
    src_test_data=[];
    tar_train_data=[];
    tar_test_data=[];
    for c=1:nClasses
        tmp_data = sdata(Y_src==c,:);
        tmp_id = 1:floor(size(tmp_data,1)/1.2);
        src_test_data = [src_test_data;tmp_data(tmp_id,:)];
        src_train_data = [src_train_data;tmp_data(tmp_id(end)+1:end,:)];
        tmp_data2 = tdata(IDX==c,:);
        tmp_id2 = 1:floor(size(tmp_data2,1)/1.2);
        tar_test_data = [tar_test_data;tmp_data2(tmp_id2,:)];
        tar_train_data = [tar_train_data;tmp_data2(tmp_id2(end)+1:end,:)];
        
    end
    src_train_label = zeros(size(src_train_data,1),1);
    src_test_label = zeros(size(src_test_data,1),1);
    tar_train_label = ones(size(tar_train_data,1),1);
    tar_test_label = ones(size(tar_test_data,1),1);
    train_data = [src_train_data;tar_train_data];
    train_label = [src_train_label; tar_train_label];
    test_data = [src_test_data;tar_test_data];
    test_label = [src_test_label; tar_test_label];
    Cls = knnclassify(test_data,train_data,train_label,1);
    acc = length(find(Cls==test_label))/length(test_label); fprintf('NN=%0.4f\n',100*acc);
    Glob_dsim=acc;

